// PromptForge OP_NET — Main Application
// Orchestrates the full forge → validate → deploy workflow

// ——— Char counter ———
document.getElementById('promptInput').addEventListener('input', function () {
  const len = this.value.length;
  document.getElementById('charCount').textContent = `${len} / 1000`;
  if (len > 950) {
    document.getElementById('charCount').style.color = 'var(--red)';
  } else {
    document.getElementById('charCount').style.color = 'var(--text-dim)';
  }
});

// ——— Main Forge Flow ———
async function forgeContract() {
  const prompt = document.getElementById('promptInput').value.trim();
  if (!prompt || prompt.length < 20) {
    showToast('Please describe your contract in more detail');
    return;
  }

  const forgeBtn = document.getElementById('forgeBtn');
  forgeBtn.disabled = true;
  forgeBtn.innerHTML = '<span class="forge-btn-text">Forging...</span><span class="forge-btn-icon">⚡</span>';

  // Show progress
  const progressTrack = document.getElementById('progressTrack');
  const outputGrid = document.getElementById('outputGrid');
  progressTrack.style.display = 'block';
  outputGrid.style.display = 'none';
  document.getElementById('deployResult').style.display = 'none';

  // Reset security panel
  resetSecurityPanel();
  document.getElementById('deployBtn').disabled = true;
  document.getElementById('deployBtn').innerHTML = '<span class="deploy-btn-text">Deploy to OP_NET Testnet</span><span class="deploy-btn-icon">🚀</span>';
  document.getElementById('deployBtn').style.background = '';
  document.getElementById('deployBtn').style.color = '';

  try {
    // Step 1: Parse
    await advanceStep(1, 12);
    await sleep(500);

    // Step 2: Generate
    await advanceStep(2, 45);
    const template = getContractCode(prompt);
    await sleep(800);

    // Step 3: Security
    await advanceStep(3, 75);
    outputGrid.style.display = 'grid';
    renderCode(template.code);
    progressTrack.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    await sleep(400);

    // Run security checks
    await runSecurityChecks(template.code);

    // Step 4: Ready
    await advanceStep(4, 100);
    await sleep(300);

    progressTrack.style.display = 'none';

    showToast(`✓ ${template.name} generated and validated`);
  } catch (err) {
    console.error(err);
    showToast('Error generating contract: ' + err.message);
    progressTrack.style.display = 'none';
  }

  forgeBtn.disabled = false;
  forgeBtn.innerHTML = '<span class="forge-btn-text">Forge Contract</span><span class="forge-btn-icon">⚡</span>';
}

function advanceStep(stepNum, pct) {
  return new Promise(resolve => {
    // Update steps
    for (let i = 1; i <= 4; i++) {
      const el = document.getElementById(`step${i}`);
      if (i < stepNum) {
        el.className = 'step done';
        el.querySelector('.step-dot').style.background = 'var(--green)';
      } else if (i === stepNum) {
        el.className = 'step active';
      } else {
        el.className = 'step';
      }
    }

    // Update step lines
    const lines = document.querySelectorAll('.step-line');
    lines.forEach((line, idx) => {
      line.className = idx < stepNum - 1 ? 'step-line done' : 'step-line';
    });

    // Update progress bar
    document.getElementById('progressFill').style.width = pct + '%';

    setTimeout(resolve, 100);
  });
}

// ——— Syntax Highlighting ———
function syntaxHighlight(code) {
  // Escape HTML first
  let escaped = code
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  // Comments
  escaped = escaped.replace(/(\/\/[^\n]*|\/\*[\s\S]*?\*\/)/g, '<span class="cmt">$1</span>');

  // Strings
  escaped = escaped.replace(/('(?:[^'\\]|\\.)*'|`(?:[^`\\]|\\.)*`|"(?:[^"\\]|\\.)*")/g, '<span class="str">$1</span>');

  // Keywords
  const keywords = ['import', 'export', 'class', 'extends', 'constructor', 'return', 'new', 'async', 'await', 'const', 'let', 'private', 'public', 'static', 'readonly', 'interface', 'for', 'if', 'else', 'true', 'false', 'null', 'undefined', 'from', 'void', 'this', 'throw', 'of'];
  const kwRegex = new RegExp(`\\b(${keywords.join('|')})\\b`, 'g');
  escaped = escaped.replace(kwRegex, '<span class="kw">$1</span>');

  // Decorators
  escaped = escaped.replace(/(@\w+)/g, '<span class="fn">$1</span>');

  // Numbers
  escaped = escaped.replace(/\b(\d+)\b/g, '<span class="num">$1</span>');

  // Class names (PascalCase)
  escaped = escaped.replace(/\b([A-Z][a-zA-Z0-9]+)\b/g, '<span class="cls">$1</span>');

  // Function calls
  escaped = escaped.replace(/\b([a-z][a-zA-Z0-9]+)(?=\()/g, '<span class="fn">$1</span>');

  return escaped;
}

function renderCode(code) {
  const el = document.getElementById('contractCode');
  el.innerHTML = syntaxHighlight(code);
}

// ——— Reset Security Panel ———
function resetSecurityPanel() {
  const checks = ['check-access', 'check-input', 'check-state', 'check-reentrant', 'check-events'];
  checks.forEach(id => {
    const el = document.getElementById(id);
    const icon = el.querySelector('.check-icon');
    const status = el.querySelector('.check-status');
    icon.className = 'check-icon pending';
    icon.textContent = '○';
    status.textContent = 'Pending';
    status.className = 'check-status';
  });

  const badge = document.getElementById('securityScore');
  badge.textContent = '—';
  badge.className = 'score-badge';

  document.getElementById('securitySummary').style.display = 'none';
}

// ——— Copy / Download ———
function copyCode() {
  const code = document.getElementById('contractCode').textContent;
  navigator.clipboard.writeText(code).then(() => showToast('Code copied'));
}

function downloadCode() {
  const code = document.getElementById('contractCode').textContent;
  const blob = new Blob([code], { type: 'text/typescript' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'opnet-contract.ts';
  a.click();
  URL.revokeObjectURL(url);
  showToast('Contract downloaded');
}

function copyField(id) {
  const text = document.getElementById(id).textContent;
  navigator.clipboard.writeText(text).then(() => showToast('Copied'));
}

// ——— Reset ———
function resetForge() {
  document.getElementById('deployResult').style.display = 'none';
  document.getElementById('outputGrid').style.display = 'none';
  document.getElementById('progressTrack').style.display = 'none';
  document.getElementById('promptInput').value = '';
  document.getElementById('charCount').textContent = '0 / 1000';
  document.getElementById('contractCode').innerHTML = '';
  resetSecurityPanel();
  document.getElementById('deployBtn').disabled = true;
  document.getElementById('deployBtn').innerHTML = '<span class="deploy-btn-text">Deploy to OP_NET Testnet</span><span class="deploy-btn-icon">🚀</span>';
  document.getElementById('deployBtn').style.background = '';
  document.getElementById('deployBtn').style.color = '';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ——— Toast ———
function showToast(msg, duration = 3000) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => {
    toast.classList.remove('show');
  }, duration);
}

// ——— Utility ———
function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ——— Keyboard shortcut ———
document.addEventListener('keydown', e => {
  if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
    forgeContract();
  }
});

// ——— Initial state ———
document.addEventListener('DOMContentLoaded', () => {
  console.log('%c⚡ PromptForge OP_NET', 'color:#F7931A;font-size:18px;font-weight:bold;');
  console.log('%cBitcoin Layer 1 Smart Contract Generator', 'color:#7A8799;font-size:12px;');
  console.log('%cConnect a wallet and forge your first contract.', 'color:#4A5568;font-size:11px;');
});
