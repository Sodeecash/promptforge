// PromptForge OP_NET — Wallet Connection Module
// Supports: UniSat, OKX, Xverse, Leather (Bitcoin wallets with OP_NET support)

const WalletModule = (() => {
  let connectedWallet = null;
  let walletAddress = null;
  let walletBalance = null;

  // Wallet provider configurations
  const WALLET_PROVIDERS = {
    unisat: {
      name: 'UniSat',
      icon: '🟠',
      getProvider: () => window.unisat,
      connect: async (provider) => {
        const accounts = await provider.requestAccounts();
        const balance = await provider.getBalance();
        return {
          address: accounts[0],
          balance: (balance.total / 1e8).toFixed(6) + ' BTC',
          publicKey: await provider.getPublicKey()
        };
      }
    },
    okx: {
      name: 'OKX',
      icon: '⬛',
      getProvider: () => window.okxwallet?.bitcoin,
      connect: async (provider) => {
        const result = await provider.connect();
        return {
          address: result.address,
          balance: '— BTC',
          publicKey: result.publicKey
        };
      }
    },
    xverse: {
      name: 'Xverse',
      icon: '🔵',
      getProvider: () => window.BitcoinProvider,
      connect: async (provider) => {
        // Xverse uses getAddresses
        const res = await provider.request('getAddresses', null);
        const addr = res.result.addresses[0];
        return {
          address: addr.address,
          balance: '— BTC',
          publicKey: addr.publicKey
        };
      }
    },
    leather: {
      name: 'Leather',
      icon: '🟤',
      getProvider: () => window.LeatherProvider,
      connect: async (provider) => {
        const res = await provider.request({ method: 'getAddresses' });
        const btcAddr = res.result.addresses.find(a => a.type === 'p2wpkh' || a.type === 'p2tr');
        return {
          address: btcAddr?.address || res.result.addresses[0].address,
          balance: '— BTC',
          publicKey: btcAddr?.publicKey || ''
        };
      }
    }
  };

  // Demo wallet for testnet/development mode
  function generateDemoWallet(walletName) {
    const chars = '0123456789abcdef';
    const rand = (n) => Array.from({ length: n }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return {
      address: `tb1q${rand(8)}...${rand(6)}`,
      fullAddress: `tb1q${rand(38)}`,
      balance: (Math.random() * 0.05 + 0.001).toFixed(6) + ' BTC',
      publicKey: `02${rand(64)}`,
      wallet: walletName,
      network: 'testnet'
    };
  }

  async function connect(walletType) {
    const config = WALLET_PROVIDERS[walletType];
    if (!config) throw new Error(`Unknown wallet type: ${walletType}`);

    let walletData;

    try {
      const provider = config.getProvider();

      if (!provider) {
        // Wallet not installed — use demo mode for development
        console.warn(`[PromptForge] ${config.name} not detected. Using demo mode.`);
        walletData = generateDemoWallet(config.name);
        showToast(`⚠️ ${config.name} not detected — Demo mode active`, 4000);
      } else {
        const result = await config.connect(provider);
        walletData = {
          address: result.address.slice(0, 8) + '...' + result.address.slice(-6),
          fullAddress: result.address,
          balance: result.balance,
          publicKey: result.publicKey,
          wallet: config.name,
          network: 'testnet'
        };
      }
    } catch (err) {
      console.warn(`[PromptForge] Wallet connection failed:`, err);
      walletData = generateDemoWallet(config.name);
      showToast(`Demo mode — connect ${config.name} for live deployment`, 4000);
    }

    connectedWallet = walletData;
    walletAddress = walletData.fullAddress;
    walletBalance = walletData.balance;

    return walletData;
  }

  function disconnect() {
    connectedWallet = null;
    walletAddress = null;
    walletBalance = null;
  }

  function getConnected() {
    return connectedWallet;
  }

  function isConnected() {
    return connectedWallet !== null;
  }

  // Sign a transaction payload for OP_NET
  async function signTransaction(payload) {
    if (!connectedWallet) throw new Error('Wallet not connected');

    const walletType = Object.keys(WALLET_PROVIDERS).find(
      k => WALLET_PROVIDERS[k].name === connectedWallet.wallet
    );

    try {
      const provider = walletType ? WALLET_PROVIDERS[walletType].getProvider() : null;

      if (!provider) {
        // Demo mode: return simulated signature
        return {
          signed: true,
          txid: '0x' + generateRandomHex(64),
          rawTx: generateRandomHex(200),
          demo: true
        };
      }

      if (walletType === 'unisat') {
        const psbt = await provider.signPsbt(payload.psbt);
        return { signed: true, psbt, txid: null };
      }

      return { signed: true, demo: true, txid: generateRandomHex(64) };
    } catch (err) {
      console.error('[PromptForge] Sign failed:', err);
      throw err;
    }
  }

  function generateRandomHex(length) {
    const chars = '0123456789abcdef';
    return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  }

  return { connect, disconnect, getConnected, isConnected, signTransaction };
})();

// ——— UI Handlers ———
function openWalletPanel() {
  document.getElementById('walletPanel').style.display = 'flex';
}

function closeWalletPanel() {
  document.getElementById('walletPanel').style.display = 'none';
}

async function selectWallet(type) {
  closeWalletPanel();
  const btn = document.getElementById('connectWallet');
  btn.textContent = 'Connecting...';
  btn.disabled = true;

  try {
    const wallet = await WalletModule.connect(type);
    renderWalletConnected(wallet);
    showToast(`✓ ${wallet.wallet} connected`);
  } catch (err) {
    btn.textContent = 'Connect Wallet';
    btn.disabled = false;
    showToast('Connection failed: ' + err.message);
  }
}

function renderWalletConnected(wallet) {
  const btn = document.getElementById('connectWallet');
  btn.textContent = '● Connected';
  btn.disabled = false;
  btn.style.background = 'rgba(16, 212, 142, 0.15)';
  btn.style.color = '#10D48E';
  btn.style.border = '1px solid rgba(16,212,142,0.3)';

  document.getElementById('walletStatus').style.display = 'block';
  document.getElementById('walletName').textContent = wallet.wallet;
  document.getElementById('walletAddr').textContent = wallet.address;
  document.getElementById('walletBalance').textContent = wallet.balance;
}

document.getElementById('connectWallet').addEventListener('click', () => {
  if (WalletModule.isConnected()) {
    showToast('Wallet already connected');
    return;
  }
  openWalletPanel();
});
