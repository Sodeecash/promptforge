// PromptForge OP_NET — Smart Contract Templates
// OP_NET TypeScript contract templates for Bitcoin Layer 1

const ContractTemplates = {

  // ————————————————————————————————
  // ESCROW CONTRACT
  // ————————————————————————————————
  escrow: {
    name: 'Escrow Contract',
    description: 'Bitcoin escrow with arbiter-controlled release',
    code: `import { OP_NET, Address, u256, Blockchain, CallResponse } from '@btc-vision/btc-runtime/runtime';
import { StoredU256 } from '@btc-vision/btc-runtime/runtime/storage/StoredU256';
import { StoredBoolean } from '@btc-vision/btc-runtime/runtime/storage/StoredBoolean';

/**
 * @title EscrowContract
 * @notice OP_NET Bitcoin Layer 1 Escrow
 * @dev Buyer deposits BTC, arbiter controls release to seller
 * @opnet testnet
 */
export class EscrowContract extends OP_NET {
  // ——— Storage Slots ———
  private readonly buyer: StoredAddress        = new StoredAddress(Blockchain.SELECTOR, 0);
  private readonly seller: StoredAddress       = new StoredAddress(Blockchain.SELECTOR, 1);
  private readonly arbiter: StoredAddress      = new StoredAddress(Blockchain.SELECTOR, 2);
  private readonly depositAmount: StoredU256   = new StoredU256(Blockchain.SELECTOR, 3);
  private readonly isDeposited: StoredBoolean  = new StoredBoolean(Blockchain.SELECTOR, 4);
  private readonly isReleased: StoredBoolean   = new StoredBoolean(Blockchain.SELECTOR, 5);
  private readonly isRefunded: StoredBoolean   = new StoredBoolean(Blockchain.SELECTOR, 6);
  private readonly locked: StoredBoolean       = new StoredBoolean(Blockchain.SELECTOR, 7);

  // ——— Events ———
  public readonly FundsDeposited: Event = Event.from('FundsDeposited', ['address', 'uint256']);
  public readonly FundsReleased: Event  = Event.from('FundsReleased', ['address', 'uint256']);
  public readonly FundsRefunded: Event  = Event.from('FundsRefunded', ['address', 'uint256']);

  constructor(
    _buyer: Address,
    _seller: Address,
    _arbiter: Address
  ) {
    super();
    // Access control: only deployer sets parties
    this.onlyOwner();
    this.buyer.set(_buyer);
    this.seller.set(_seller);
    this.arbiter.set(_arbiter);
    this.locked.set(false);
    this.log('EscrowContract initialized on OP_NET Testnet');
  }

  /**
   * @notice Buyer deposits BTC into escrow
   * @dev Reentrancy guarded via mutex lock
   */
  @method
  public deposit(): CallResponse {
    this.nonReentrant();
    this.require(!this.isDeposited.get(), 'Already deposited');
    this.require(
      Blockchain.msgSender() === this.buyer.get(),
      'Only buyer can deposit'
    );
    // Input validation: amount must be > 0
    const amount = Blockchain.msgValue();
    this.require(amount > u256(0), 'Deposit must be > 0');

    this.depositAmount.set(amount);
    this.isDeposited.set(true);

    this.emit(this.FundsDeposited, [this.buyer.get(), amount]);
    this.log(\`Escrowed \${amount} satoshis from \${this.buyer.get()}\`);
    return CallResponse.ok();
  }

  /**
   * @notice Arbiter releases funds to seller
   */
  @method
  public release(): CallResponse {
    this.nonReentrant();
    this.require(
      Blockchain.msgSender() === this.arbiter.get(),
      'Only arbiter can release'
    );
    this.require(this.isDeposited.get(), 'No funds in escrow');
    this.require(!this.isReleased.get(), 'Already released');
    this.require(!this.isRefunded.get(), 'Already refunded');

    const amount = this.depositAmount.get();
    this.isReleased.set(true);

    // Safe state: update before transfer (CEI pattern)
    Blockchain.transfer(this.seller.get(), amount);
    this.emit(this.FundsReleased, [this.seller.get(), amount]);
    this.log(\`Released \${amount} satoshis to seller\`);
    return CallResponse.ok();
  }

  /**
   * @notice Arbiter refunds buyer
   */
  @method
  public refund(): CallResponse {
    this.nonReentrant();
    this.require(
      Blockchain.msgSender() === this.arbiter.get(),
      'Only arbiter can refund'
    );
    this.require(this.isDeposited.get(), 'No funds to refund');
    this.require(!this.isReleased.get(), 'Already released');
    this.require(!this.isRefunded.get(), 'Already refunded');

    const amount = this.depositAmount.get();
    this.isRefunded.set(true);

    Blockchain.transfer(this.buyer.get(), amount);
    this.emit(this.FundsRefunded, [this.buyer.get(), amount]);
    this.log('Funds refunded to buyer');
    return CallResponse.ok();
  }

  /**
   * @notice View escrow state
   */
  @view
  public getStatus(): object {
    return {
      buyer: this.buyer.get(),
      seller: this.seller.get(),
      arbiter: this.arbiter.get(),
      amount: this.depositAmount.get(),
      deposited: this.isDeposited.get(),
      released: this.isReleased.get(),
      refunded: this.isRefunded.get()
    };
  }

  // ——— Reentrancy Guard ———
  private nonReentrant(): void {
    this.require(!this.locked.get(), 'ReentrancyGuard: reentrant call');
    this.locked.set(true);
    // Lock is released after execution by OP_NET runtime
  }
}`,
    type: 'escrow'
  },

  // ————————————————————————————————
  // MILESTONE PAYMENT
  // ————————————————————————————————
  milestone: {
    name: 'Milestone Payment Contract',
    description: 'Stage-gated payments released on milestone completion',
    code: `import { OP_NET, Address, u256, Blockchain, CallResponse } from '@btc-vision/btc-runtime/runtime';

/**
 * @title MilestonePayment
 * @notice OP_NET milestone-based payment with BTC
 * @dev Client funds; validator approves each milestone
 */
export class MilestonePayment extends OP_NET {
  private readonly client: StoredAddress        = new StoredAddress(Blockchain.SELECTOR, 0);
  private readonly contractor: StoredAddress    = new StoredAddress(Blockchain.SELECTOR, 1);
  private readonly validator: StoredAddress     = new StoredAddress(Blockchain.SELECTOR, 2);
  private readonly totalAmount: StoredU256      = new StoredU256(Blockchain.SELECTOR, 3);
  private readonly milestoneCount: StoredU256   = new StoredU256(Blockchain.SELECTOR, 4);
  private readonly currentMilestone: StoredU256 = new StoredU256(Blockchain.SELECTOR, 5);
  private readonly locked: StoredBoolean        = new StoredBoolean(Blockchain.SELECTOR, 6);
  private readonly completed: StoredBoolean     = new StoredBoolean(Blockchain.SELECTOR, 7);

  public readonly MilestoneApproved: Event = Event.from('MilestoneApproved', ['uint256', 'address', 'uint256']);
  public readonly ProjectComplete: Event   = Event.from('ProjectComplete', ['address', 'uint256']);
  public readonly FundedEvent: Event       = Event.from('Funded', ['address', 'uint256', 'uint256']);

  constructor(_contractor: Address, _validator: Address, _milestones: u256) {
    super();
    this.onlyOwner();
    this.require(_milestones > u256(0) && _milestones <= u256(10), 'Milestones: 1-10');
    this.client.set(Blockchain.msgSender());
    this.contractor.set(_contractor);
    this.validator.set(_validator);
    this.milestoneCount.set(_milestones);
    this.currentMilestone.set(u256(0));
    this.locked.set(false);
    this.completed.set(false);
  }

  @method
  public fund(): CallResponse {
    this.nonReentrant();
    this.require(
      Blockchain.msgSender() === this.client.get(),
      'Only client can fund'
    );
    const amount = Blockchain.msgValue();
    this.require(amount > u256(0), 'Amount must be > 0');
    this.totalAmount.set(amount);
    this.emit(this.FundedEvent, [this.client.get(), amount, this.milestoneCount.get()]);
    return CallResponse.ok();
  }

  @method
  public approveMilestone(): CallResponse {
    this.nonReentrant();
    this.require(
      Blockchain.msgSender() === this.validator.get(),
      'Only validator'
    );
    this.require(!this.completed.get(), 'Project complete');

    const current = this.currentMilestone.get();
    const total = this.milestoneCount.get();
    this.require(current < total, 'All milestones done');

    const perMilestone = this.totalAmount.get() / total;
    this.currentMilestone.set(current + u256(1));

    // CEI: update state before transfer
    Blockchain.transfer(this.contractor.get(), perMilestone);

    if (this.currentMilestone.get() >= total) {
      this.completed.set(true);
      this.emit(this.ProjectComplete, [this.contractor.get(), this.totalAmount.get()]);
    }

    this.emit(this.MilestoneApproved, [current + u256(1), this.contractor.get(), perMilestone]);
    return CallResponse.ok();
  }

  @view
  public getProgress(): object {
    return {
      current: this.currentMilestone.get(),
      total: this.milestoneCount.get(),
      perMilestone: this.totalAmount.get() / this.milestoneCount.get(),
      completed: this.completed.get()
    };
  }

  private nonReentrant(): void {
    this.require(!this.locked.get(), 'ReentrancyGuard');
    this.locked.set(true);
  }
}`,
    type: 'milestone'
  },

  // ————————————————————————————————
  // MULTISIG VAULT
  // ————————————————————————————————
  multisig: {
    name: 'Multi-Signature Vault',
    description: 'M-of-N Bitcoin vault requiring multiple approvals',
    code: `import { OP_NET, Address, u256, Blockchain, CallResponse } from '@btc-vision/btc-runtime/runtime';

/**
 * @title MultiSigVault
 * @notice OP_NET M-of-N multi-signature Bitcoin vault
 * @dev Requires threshold signatures before releasing funds
 */
export class MultiSigVault extends OP_NET {
  private readonly threshold: StoredU256    = new StoredU256(Blockchain.SELECTOR, 0);
  private readonly ownerCount: StoredU256   = new StoredU256(Blockchain.SELECTOR, 1);
  private readonly txNonce: StoredU256      = new StoredU256(Blockchain.SELECTOR, 2);
  private readonly locked: StoredBoolean    = new StoredBoolean(Blockchain.SELECTOR, 3);

  // Maps: txId -> approvalCount, txId -> executed
  private approvals: Map<u256, u256>   = new Map();
  private executed: Map<u256, boolean> = new Map();
  private owners: Set<Address>         = new Set();
  private txTargets: Map<u256, Address>  = new Map();
  private txAmounts: Map<u256, u256>   = new Map();

  public readonly TransactionProposed: Event = Event.from('Proposed', ['uint256', 'address', 'uint256', 'address']);
  public readonly TransactionApproved: Event = Event.from('Approved', ['uint256', 'address', 'uint256']);
  public readonly TransactionExecuted: Event = Event.from('Executed', ['uint256', 'address', 'uint256']);
  public readonly VaultDeposit: Event        = Event.from('Deposit', ['address', 'uint256']);

  constructor(_owners: Address[], _threshold: u256) {
    super();
    this.require(_owners.length >= 2, 'Min 2 owners');
    this.require(_threshold >= u256(2), 'Min threshold: 2');
    this.require(_threshold <= u256(_owners.length), 'Threshold <= owners');

    for (const owner of _owners) {
      this.require(owner !== Address.zero(), 'Invalid owner');
      this.owners.add(owner);
    }

    this.threshold.set(_threshold);
    this.ownerCount.set(u256(_owners.length));
    this.txNonce.set(u256(0));
    this.locked.set(false);
    this.log(\`MultiSigVault initialized: \${_owners.length}-of-\${_threshold}\`);
  }

  @method
  public deposit(): CallResponse {
    const amount = Blockchain.msgValue();
    this.require(amount > u256(0), 'Deposit > 0');
    this.emit(this.VaultDeposit, [Blockchain.msgSender(), amount]);
    return CallResponse.ok();
  }

  @method
  public proposeTransaction(to: Address, amount: u256): CallResponse {
    this.requireOwner();
    this.require(amount > u256(0), 'Amount > 0');
    this.require(to !== Address.zero(), 'Invalid recipient');

    const nonce = this.txNonce.get();
    this.txTargets.set(nonce, to);
    this.txAmounts.set(nonce, amount);
    this.approvals.set(nonce, u256(0));
    this.executed.set(nonce, false);
    this.txNonce.set(nonce + u256(1));

    this.emit(this.TransactionProposed, [nonce, to, amount, Blockchain.msgSender()]);
    return CallResponse.ok();
  }

  @method
  public approve(txId: u256): CallResponse {
    this.nonReentrant();
    this.requireOwner();
    this.require(!this.executed.get(txId), 'Already executed');

    const currentApprovals = this.approvals.get(txId) || u256(0);
    this.approvals.set(txId, currentApprovals + u256(1));

    const newCount = currentApprovals + u256(1);
    this.emit(this.TransactionApproved, [txId, Blockchain.msgSender(), newCount]);

    if (newCount >= this.threshold.get()) {
      this.execute(txId);
    }
    return CallResponse.ok();
  }

  private execute(txId: u256): void {
    const to = this.txTargets.get(txId);
    const amount = this.txAmounts.get(txId);
    this.require(!!to && !!amount, 'Invalid tx');
    this.executed.set(txId, true);
    Blockchain.transfer(to!, amount!);
    this.emit(this.TransactionExecuted, [txId, to, amount]);
  }

  private requireOwner(): void {
    this.require(this.owners.has(Blockchain.msgSender()), 'Not an owner');
  }

  private nonReentrant(): void {
    this.require(!this.locked.get(), 'Reentrant');
    this.locked.set(true);
  }

  @view
  public getVaultInfo(): object {
    return {
      threshold: this.threshold.get(),
      ownerCount: this.ownerCount.get(),
      txCount: this.txNonce.get()
    };
  }
}`,
    type: 'multisig'
  },

  // ————————————————————————————————
  // DAO VOTING
  // ————————————————————————————————
  dao: {
    name: 'DAO Voting Contract',
    description: 'On-chain governance with proposal and vote counting',
    code: `import { OP_NET, Address, u256, Blockchain, CallResponse } from '@btc-vision/btc-runtime/runtime';

/**
 * @title DAOVoting
 * @notice OP_NET on-chain governance for Bitcoin DAOs
 * @dev Stake-weighted proposal voting with execution
 */
export class DAOVoting extends OP_NET {
  private readonly quorum: StoredU256      = new StoredU256(Blockchain.SELECTOR, 0);
  private readonly votingPeriod: StoredU256 = new StoredU256(Blockchain.SELECTOR, 1);
  private readonly proposalCount: StoredU256 = new StoredU256(Blockchain.SELECTOR, 2);
  private readonly locked: StoredBoolean   = new StoredBoolean(Blockchain.SELECTOR, 3);

  private proposals: Map<u256, Proposal> = new Map();
  private votes: Map<string, boolean>    = new Map(); // txId:voter -> voted
  private stakes: Map<Address, u256>     = new Map();

  public readonly ProposalCreated: Event  = Event.from('ProposalCreated', ['uint256', 'address', 'string', 'uint256']);
  public readonly VoteCast: Event         = Event.from('VoteCast', ['uint256', 'address', 'bool', 'uint256']);
  public readonly ProposalExecuted: Event = Event.from('ProposalExecuted', ['uint256', 'bool']);
  public readonly StakeDeposited: Event   = Event.from('StakeDeposited', ['address', 'uint256']);

  constructor(_quorumPercent: u256, _votingPeriodBlocks: u256) {
    super();
    this.require(_quorumPercent > u256(0) && _quorumPercent <= u256(100), 'Quorum: 1-100%');
    this.require(_votingPeriodBlocks >= u256(10), 'Min 10 blocks');
    this.quorum.set(_quorumPercent);
    this.votingPeriod.set(_votingPeriodBlocks);
    this.proposalCount.set(u256(0));
  }

  @method
  public stake(): CallResponse {
    const amount = Blockchain.msgValue();
    this.require(amount > u256(0), 'Stake > 0');
    const current = this.stakes.get(Blockchain.msgSender()) || u256(0);
    this.stakes.set(Blockchain.msgSender(), current + amount);
    this.emit(this.StakeDeposited, [Blockchain.msgSender(), amount]);
    return CallResponse.ok();
  }

  @method
  public createProposal(description: string, calldata: string): CallResponse {
    const stake = this.stakes.get(Blockchain.msgSender()) || u256(0);
    this.require(stake > u256(0), 'Must stake to propose');
    this.require(description.length > 0, 'Empty description');

    const id = this.proposalCount.get();
    const endBlock = Blockchain.blockNumber() + this.votingPeriod.get();

    this.proposals.set(id, {
      id, description, calldata,
      proposer: Blockchain.msgSender(),
      forVotes: u256(0),
      againstVotes: u256(0),
      startBlock: Blockchain.blockNumber(),
      endBlock,
      executed: false,
      passed: false
    });

    this.proposalCount.set(id + u256(1));
    this.emit(this.ProposalCreated, [id, Blockchain.msgSender(), description, endBlock]);
    return CallResponse.ok();
  }

  @method
  public castVote(proposalId: u256, support: boolean): CallResponse {
    this.nonReentrant();
    const proposal = this.proposals.get(proposalId);
    this.require(!!proposal, 'Proposal not found');
    this.require(Blockchain.blockNumber() <= proposal!.endBlock, 'Voting ended');

    const voteKey = \`\${proposalId}:\${Blockchain.msgSender()}\`;
    this.require(!this.votes.get(voteKey), 'Already voted');

    const voterStake = this.stakes.get(Blockchain.msgSender()) || u256(0);
    this.require(voterStake > u256(0), 'No voting power');

    this.votes.set(voteKey, true);
    if (support) {
      proposal!.forVotes = proposal!.forVotes + voterStake;
    } else {
      proposal!.againstVotes = proposal!.againstVotes + voterStake;
    }
    this.proposals.set(proposalId, proposal!);
    this.emit(this.VoteCast, [proposalId, Blockchain.msgSender(), support, voterStake]);
    return CallResponse.ok();
  }

  @method
  public execute(proposalId: u256): CallResponse {
    this.nonReentrant();
    const proposal = this.proposals.get(proposalId);
    this.require(!!proposal, 'Not found');
    this.require(Blockchain.blockNumber() > proposal!.endBlock, 'Voting active');
    this.require(!proposal!.executed, 'Already executed');

    const totalVotes = proposal!.forVotes + proposal!.againstVotes;
    const passed = proposal!.forVotes > proposal!.againstVotes;
    proposal!.executed = true;
    proposal!.passed = passed;
    this.proposals.set(proposalId, proposal!);

    this.emit(this.ProposalExecuted, [proposalId, passed]);
    return CallResponse.ok();
  }

  @view
  public getProposal(id: u256): object {
    return this.proposals.get(id) || {};
  }

  private nonReentrant(): void {
    this.require(!this.locked.get(), 'Reentrant');
    this.locked.set(true);
  }
}

interface Proposal {
  id: u256; description: string; calldata: string;
  proposer: Address; forVotes: u256; againstVotes: u256;
  startBlock: u256; endBlock: u256; executed: boolean; passed: boolean;
}`,
    type: 'dao'
  },

  // ————————————————————————————————
  // STAKING POOL
  // ————————————————————————————————
  staking: {
    name: 'Staking Pool Contract',
    description: 'BTC staking pool with rewards distribution',
    code: `import { OP_NET, Address, u256, Blockchain, CallResponse } from '@btc-vision/btc-runtime/runtime';

/**
 * @title StakingPool
 * @notice OP_NET Bitcoin staking pool with linear rewards
 * @dev Users stake BTC; rewards distributed proportionally
 */
export class StakingPool extends OP_NET {
  private readonly rewardRate: StoredU256      = new StoredU256(Blockchain.SELECTOR, 0);
  private readonly totalStaked: StoredU256     = new StoredU256(Blockchain.SELECTOR, 1);
  private readonly rewardPerToken: StoredU256  = new StoredU256(Blockchain.SELECTOR, 2);
  private readonly lastUpdateBlock: StoredU256 = new StoredU256(Blockchain.SELECTOR, 3);
  private readonly locked: StoredBoolean       = new StoredBoolean(Blockchain.SELECTOR, 4);

  private stakes: Map<Address, u256>          = new Map();
  private rewards: Map<Address, u256>         = new Map();
  private userRewardPerToken: Map<Address, u256> = new Map();

  public readonly Staked: Event    = Event.from('Staked', ['address', 'uint256']);
  public readonly Unstaked: Event  = Event.from('Unstaked', ['address', 'uint256']);
  public readonly Claimed: Event   = Event.from('RewardClaimed', ['address', 'uint256']);
  public readonly Funded: Event    = Event.from('PoolFunded', ['address', 'uint256']);

  constructor(_rewardRatePerBlock: u256) {
    super();
    this.onlyOwner();
    this.require(_rewardRatePerBlock > u256(0), 'Rate > 0');
    this.rewardRate.set(_rewardRatePerBlock);
    this.totalStaked.set(u256(0));
    this.rewardPerToken.set(u256(0));
    this.lastUpdateBlock.set(Blockchain.blockNumber());
  }

  @method
  public fundPool(): CallResponse {
    this.onlyOwner();
    const amount = Blockchain.msgValue();
    this.require(amount > u256(0), 'Fund > 0');
    this.emit(this.Funded, [Blockchain.msgSender(), amount]);
    return CallResponse.ok();
  }

  @method
  public stake(): CallResponse {
    this.nonReentrant();
    const amount = Blockchain.msgValue();
    this.require(amount > u256(0), 'Stake > 0');

    this.updateRewards(Blockchain.msgSender());

    const current = this.stakes.get(Blockchain.msgSender()) || u256(0);
    this.stakes.set(Blockchain.msgSender(), current + amount);
    this.totalStaked.set(this.totalStaked.get() + amount);

    this.emit(this.Staked, [Blockchain.msgSender(), amount]);
    return CallResponse.ok();
  }

  @method
  public unstake(amount: u256): CallResponse {
    this.nonReentrant();
    const staked = this.stakes.get(Blockchain.msgSender()) || u256(0);
    this.require(staked >= amount && amount > u256(0), 'Insufficient stake');

    this.updateRewards(Blockchain.msgSender());

    this.stakes.set(Blockchain.msgSender(), staked - amount);
    this.totalStaked.set(this.totalStaked.get() - amount);

    // CEI: state updated, now transfer
    Blockchain.transfer(Blockchain.msgSender(), amount);
    this.emit(this.Unstaked, [Blockchain.msgSender(), amount]);
    return CallResponse.ok();
  }

  @method
  public claimRewards(): CallResponse {
    this.nonReentrant();
    this.updateRewards(Blockchain.msgSender());

    const earned = this.rewards.get(Blockchain.msgSender()) || u256(0);
    this.require(earned > u256(0), 'No rewards');

    this.rewards.set(Blockchain.msgSender(), u256(0));
    Blockchain.transfer(Blockchain.msgSender(), earned);
    this.emit(this.Claimed, [Blockchain.msgSender(), earned]);
    return CallResponse.ok();
  }

  private updateRewards(user: Address): void {
    const total = this.totalStaked.get();
    if (total > u256(0)) {
      const blocksElapsed = Blockchain.blockNumber() - this.lastUpdateBlock.get();
      const newReward = blocksElapsed * this.rewardRate.get();
      const newRPT = this.rewardPerToken.get() + (newReward * u256(1e18)) / total;
      this.rewardPerToken.set(newRPT);
    }
    this.lastUpdateBlock.set(Blockchain.blockNumber());

    const userStake = this.stakes.get(user) || u256(0);
    if (userStake > u256(0)) {
      const userRPT = this.userRewardPerToken.get(user) || u256(0);
      const pending = (userStake * (this.rewardPerToken.get() - userRPT)) / u256(1e18);
      const current = this.rewards.get(user) || u256(0);
      this.rewards.set(user, current + pending);
    }
    this.userRewardPerToken.set(user, this.rewardPerToken.get());
  }

  @view
  public getStakeInfo(user: Address): object {
    return {
      staked: this.stakes.get(user) || u256(0),
      rewards: this.rewards.get(user) || u256(0),
      totalStaked: this.totalStaked.get(),
      rewardRate: this.rewardRate.get()
    };
  }

  private nonReentrant(): void {
    this.require(!this.locked.get(), 'Reentrant');
    this.locked.set(true);
  }
}`,
    type: 'staking'
  },

  // ————————————————————————————————
  // CROWDFUNDING
  // ————————————————————————————————
  crowdfund: {
    name: 'Crowdfunding Contract',
    description: 'Bitcoin crowdfunding with soft cap and refund logic',
    code: `import { OP_NET, Address, u256, Blockchain, CallResponse } from '@btc-vision/btc-runtime/runtime';

/**
 * @title CrowdfundingContract
 * @notice OP_NET Bitcoin crowdfunding with refund protection
 * @dev Soft cap model: refund all if goal not met by deadline
 */
export class CrowdfundingContract extends OP_NET {
  private readonly goal: StoredU256       = new StoredU256(Blockchain.SELECTOR, 0);
  private readonly deadline: StoredU256   = new StoredU256(Blockchain.SELECTOR, 1);
  private readonly raised: StoredU256     = new StoredU256(Blockchain.SELECTOR, 2);
  private readonly claimed: StoredBoolean = new StoredBoolean(Blockchain.SELECTOR, 3);
  private readonly locked: StoredBoolean  = new StoredBoolean(Blockchain.SELECTOR, 4);
  private readonly finalized: StoredBoolean = new StoredBoolean(Blockchain.SELECTOR, 5);

  private contributions: Map<Address, u256> = new Map();

  public readonly ContributionReceived: Event = Event.from('Contribution', ['address', 'uint256', 'uint256']);
  public readonly GoalReached: Event          = Event.from('GoalReached', ['uint256', 'address']);
  public readonly RefundIssued: Event         = Event.from('Refund', ['address', 'uint256']);
  public readonly FundsClaimed: Event         = Event.from('FundsClaimed', ['address', 'uint256']);

  constructor(_goalSatoshis: u256, _durationBlocks: u256) {
    super();
    this.onlyOwner();
    this.require(_goalSatoshis > u256(0), 'Goal > 0');
    this.require(_durationBlocks >= u256(144), 'Min 144 blocks (~1 day)');

    this.goal.set(_goalSatoshis);
    this.deadline.set(Blockchain.blockNumber() + _durationBlocks);
    this.raised.set(u256(0));
    this.claimed.set(false);
    this.finalized.set(false);
    this.log(\`Campaign started: goal \${_goalSatoshis} sats, ends block \${this.deadline.get()}\`);
  }

  @method
  public contribute(): CallResponse {
    this.nonReentrant();
    this.require(Blockchain.blockNumber() < this.deadline.get(), 'Campaign ended');
    this.require(!this.finalized.get(), 'Finalized');

    const amount = Blockchain.msgValue();
    this.require(amount > u256(0), 'Contribution > 0');

    const existing = this.contributions.get(Blockchain.msgSender()) || u256(0);
    this.contributions.set(Blockchain.msgSender(), existing + amount);

    const newTotal = this.raised.get() + amount;
    this.raised.set(newTotal);

    this.emit(this.ContributionReceived, [Blockchain.msgSender(), amount, newTotal]);

    if (newTotal >= this.goal.get()) {
      this.emit(this.GoalReached, [newTotal, Blockchain.msgSender()]);
      this.log('Funding goal reached!');
    }
    return CallResponse.ok();
  }

  @method
  public claimFunds(): CallResponse {
    this.nonReentrant();
    this.onlyOwner();
    this.require(this.raised.get() >= this.goal.get(), 'Goal not met');
    this.require(Blockchain.blockNumber() >= this.deadline.get(), 'Campaign active');
    this.require(!this.claimed.get(), 'Already claimed');

    const total = this.raised.get();
    this.claimed.set(true);
    this.finalized.set(true);

    Blockchain.transfer(Blockchain.msgSender(), total);
    this.emit(this.FundsClaimed, [Blockchain.msgSender(), total]);
    return CallResponse.ok();
  }

  @method
  public refund(): CallResponse {
    this.nonReentrant();
    this.require(
      Blockchain.blockNumber() >= this.deadline.get() && this.raised.get() < this.goal.get(),
      'Refund not available'
    );
    this.require(!this.claimed.get(), 'Funds claimed, no refund');

    const contribution = this.contributions.get(Blockchain.msgSender()) || u256(0);
    this.require(contribution > u256(0), 'No contribution');

    // CEI: zero before transfer
    this.contributions.set(Blockchain.msgSender(), u256(0));
    Blockchain.transfer(Blockchain.msgSender(), contribution);
    this.emit(this.RefundIssued, [Blockchain.msgSender(), contribution]);
    return CallResponse.ok();
  }

  @view
  public getCampaignStatus(): object {
    const now = Blockchain.blockNumber();
    return {
      goal: this.goal.get(),
      raised: this.raised.get(),
      deadline: this.deadline.get(),
      blocksLeft: this.deadline.get() > now ? this.deadline.get() - now : u256(0),
      goalMet: this.raised.get() >= this.goal.get(),
      finalized: this.finalized.get(),
      percentFunded: (this.raised.get() * u256(100)) / this.goal.get()
    };
  }

  private nonReentrant(): void {
    this.require(!this.locked.get(), 'Reentrant');
    this.locked.set(true);
  }
}`,
    type: 'crowdfund'
  }
};

// Template prompts for UI chips
const TEMPLATE_PROMPTS = {
  escrow: 'Create a Bitcoin escrow contract on OP_NET where a buyer deposits BTC, a designated arbiter can either release funds to the seller or refund the buyer, with full reentrancy protection and event logging for all state changes.',
  milestone: 'Build a milestone-based payment contract for OP_NET Bitcoin. A client funds the contract, a validator approves each milestone stage, and the contractor receives proportional BTC payments per milestone. Include access control and safe state transitions.',
  multisig: 'Deploy a multi-signature vault on OP_NET requiring M-of-N owner approvals before releasing Bitcoin. Support proposal creation, individual approvals, and automatic execution when threshold is reached. Protect against reentrancy.',
  dao: 'Create an OP_NET DAO governance contract where holders can stake BTC for voting power, propose actions, vote for or against proposals, and execute passed proposals after a voting period. Include quorum requirements and event logging.',
  staking: 'Build a Bitcoin staking pool on OP_NET where users stake BTC and earn proportional rewards distributed per block. Include stake, unstake, and claim functions with reentrancy guards and accurate reward accounting.',
  crowdfund: 'Create a Bitcoin crowdfunding contract on OP_NET with a funding goal in satoshis and a block-based deadline. If the goal is met, the owner can claim funds. If not, contributors can get full refunds. Include all safety checks.'
};

function fillTemplate(type) {
  const prompt = TEMPLATE_PROMPTS[type];
  if (!prompt) return;
  const textarea = document.getElementById('promptInput');
  textarea.value = prompt;
  textarea.dispatchEvent(new Event('input'));
  textarea.focus();
}

function getContractCode(prompt) {
  const lower = prompt.toLowerCase();
  if (lower.includes('escrow') || lower.includes('arbiter')) return ContractTemplates.escrow;
  if (lower.includes('milestone') || lower.includes('stage')) return ContractTemplates.milestone;
  if (lower.includes('multisig') || lower.includes('multi-sig') || lower.includes('vault') || lower.includes('m-of-n')) return ContractTemplates.multisig;
  if (lower.includes('dao') || lower.includes('voting') || lower.includes('governance') || lower.includes('proposal')) return ContractTemplates.dao;
  if (lower.includes('staking') || lower.includes('stake') || lower.includes('reward')) return ContractTemplates.staking;
  if (lower.includes('crowdfund') || lower.includes('crowd') || lower.includes('campaign')) return ContractTemplates.crowdfund;
  // Default to escrow
  return ContractTemplates.escrow;
}
