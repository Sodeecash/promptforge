// PromptForge OP_NET — Animated Bitcoin Background
(function () {
  const canvas = document.getElementById('bgCanvas');
  const ctx = canvas.getContext('2d');

  let W, H, particles = [], hexagons = [], animId;

  function resize() {
    W = canvas.width = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }

  class Particle {
    constructor() { this.reset(); }
    reset() {
      this.x = Math.random() * W;
      this.y = Math.random() * H;
      this.vx = (Math.random() - 0.5) * 0.3;
      this.vy = (Math.random() - 0.5) * 0.3 - 0.1;
      this.alpha = Math.random() * 0.5 + 0.1;
      this.size = Math.random() * 1.5 + 0.5;
      this.color = Math.random() > 0.7 ? '#F7931A' : '#4A5568';
      this.life = 0;
      this.maxLife = Math.random() * 400 + 200;
    }
    update() {
      this.x += this.vx;
      this.y += this.vy;
      this.life++;
      if (this.life > this.maxLife || this.y < -10) this.reset();
    }
    draw() {
      ctx.save();
      ctx.globalAlpha = this.alpha * (1 - this.life / this.maxLife);
      ctx.fillStyle = this.color;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  class Hexagon {
    constructor() { this.reset(); }
    reset() {
      this.x = Math.random() * W;
      this.y = Math.random() * H;
      this.r = Math.random() * 60 + 20;
      this.alpha = Math.random() * 0.06 + 0.01;
      this.rot = Math.random() * Math.PI;
      this.rotV = (Math.random() - 0.5) * 0.002;
      this.vy = -0.15 - Math.random() * 0.1;
      this.drift = (Math.random() - 0.5) * 0.05;
    }
    update() {
      this.y += this.vy;
      this.x += this.drift;
      this.rot += this.rotV;
      if (this.y + this.r < 0) {
        this.y = H + this.r;
        this.x = Math.random() * W;
      }
    }
    draw() {
      ctx.save();
      ctx.translate(this.x, this.y);
      ctx.rotate(this.rot);
      ctx.globalAlpha = this.alpha;
      ctx.strokeStyle = '#F7931A';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = (i * Math.PI * 2) / 6 - Math.PI / 6;
        if (i === 0) ctx.moveTo(Math.cos(a) * this.r, Math.sin(a) * this.r);
        else ctx.lineTo(Math.cos(a) * this.r, Math.sin(a) * this.r);
      }
      ctx.closePath();
      ctx.stroke();
      ctx.restore();
    }
  }

  class BitcoinSymbol {
    constructor() { this.reset(); }
    reset() {
      this.x = Math.random() * W;
      this.y = H + 40;
      this.alpha = Math.random() * 0.04 + 0.01;
      this.size = Math.random() * 18 + 8;
      this.vy = -0.4 - Math.random() * 0.3;
      this.vx = (Math.random() - 0.5) * 0.1;
    }
    update() {
      this.y += this.vy;
      this.x += this.vx;
      if (this.y < -50) this.reset();
    }
    draw() {
      ctx.save();
      ctx.globalAlpha = this.alpha;
      ctx.fillStyle = '#F7931A';
      ctx.font = `bold ${this.size}px monospace`;
      ctx.textAlign = 'center';
      ctx.fillText('₿', this.x, this.y);
      ctx.restore();
    }
  }

  // Grid lines
  function drawGrid() {
    ctx.save();
    ctx.strokeStyle = 'rgba(247, 147, 26, 0.03)';
    ctx.lineWidth = 1;
    const size = 80;
    for (let x = 0; x < W; x += size) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, H);
      ctx.stroke();
    }
    for (let y = 0; y < H; y += size) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(W, y);
      ctx.stroke();
    }
    ctx.restore();
  }

  // Connection lines between nearby particles
  function drawConnections() {
    ctx.save();
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 100) {
          ctx.globalAlpha = (1 - dist / 100) * 0.08;
          ctx.strokeStyle = '#F7931A';
          ctx.lineWidth = 0.5;
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.stroke();
        }
      }
    }
    ctx.restore();
  }

  let btcSymbols = [];

  function init() {
    particles = Array.from({ length: 60 }, () => new Particle());
    hexagons = Array.from({ length: 12 }, () => new Hexagon());
    btcSymbols = Array.from({ length: 10 }, () => new BitcoinSymbol());
  }

  function loop() {
    ctx.clearRect(0, 0, W, H);

    // Deep background gradient
    const grad = ctx.createRadialGradient(W * 0.3, H * 0.3, 0, W * 0.3, H * 0.3, W * 0.8);
    grad.addColorStop(0, 'rgba(247, 147, 26, 0.04)');
    grad.addColorStop(0.5, 'rgba(13, 17, 23, 0)');
    grad.addColorStop(1, 'rgba(8, 10, 14, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    drawGrid();

    hexagons.forEach(h => { h.update(); h.draw(); });
    drawConnections();
    particles.forEach(p => { p.update(); p.draw(); });
    btcSymbols.forEach(b => { b.update(); b.draw(); });

    animId = requestAnimationFrame(loop);
  }

  window.addEventListener('resize', () => { resize(); init(); });
  resize();
  init();
  loop();
})();
