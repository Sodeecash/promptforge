// PromptForge OP_NET — Security Validation Layer
// Performs static analysis checks on generated OP_NET contract code

const SecurityModule = (() => {

  const CHECKS = [
    {
      id: 'check-access',
      label: 'Access Control',
      patterns: {
        pass: ['onlyOwner', 'requireOwner', 'msgSender', 'require(.*owner', 'require(.*sender'],
        fail: []
      },
      desc: 'Owner/role modifiers present',
      failDesc: 'No access control detected'
    },
    {
      id: 'check-input',
      label: 'Input Validation',
      patterns: {
        pass: ['this.require(', 'require(', '> u256(0)', '>= u256', 'this.require(!', 'length > 0'],
        fail: []
      },
      desc: 'Parameter validation guards found',
      failDesc: 'Missing input validation'
    },
    {
      id: 'check-state',
      label: 'State Transitions',
      patterns: {
        pass: ['isDeposited', 'isReleased', 'executed', 'finalized', 'completed', 'StoredBoolean', '.set(true)', '.set(false)'],
        fail: []
      },
      desc: 'State machine flags verified',
      failDesc: 'State transitions unclear'
    },
    {
      id: 'check-reentrant',
      label: 'Reentrancy Protection',
      patterns: {
        pass: ['nonReentrant', 'locked', 'ReentrancyGuard', 'this.locked'],
        fail: []
      },
      desc: 'Mutex/guard pattern detected',
      failDesc: 'No reentrancy protection found'
    },
    {
      id: 'check-events',
      label: 'Event Logging',
      patterns: {
        pass: ['this.emit(', 'Event.from(', 'this.log('],
        fail: []
      },
      desc: 'Contract events properly emitted',
      failDesc: 'Event logging missing'
    }
  ];

  function checkPattern(code, patterns) {
    return patterns.some(p => {
      const regex = new RegExp(p, 'i');
      return regex.test(code);
    });
  }

  async function runChecks(code, onCheckComplete) {
    const results = [];

    for (let i = 0; i < CHECKS.length; i++) {
      const check = CHECKS[i];

      // Simulate async checking delay for UX realism
      await delay(600 + Math.random() * 400);

      const passed = checkPattern(code, check.patterns.pass);
      const hasFail = check.patterns.fail.length > 0 && checkPattern(code, check.patterns.fail);

      const result = {
        id: check.id,
        label: check.label,
        passed: passed && !hasFail,
        desc: passed ? check.desc : check.failDesc
      };

      results.push(result);
      if (onCheckComplete) onCheckComplete(result, i);
    }

    return results;
  }

  function calculateScore(results) {
    const passed = results.filter(r => r.passed).length;
    const total = results.length;
    const pct = Math.round((passed / total) * 100);

    let grade, cls;
    if (pct >= 80) { grade = `${pct}% — SECURE`; cls = 'pass'; }
    else if (pct >= 60) { grade = `${pct}% — REVIEW`; cls = 'warn'; }
    else { grade = `${pct}% — ISSUES`; cls = 'fail'; }

    return { pct, grade, cls, passed, total };
  }

  function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  return { runChecks, calculateScore };
})();

// ——— UI: Run Security Checks ———
async function runSecurityChecks(code) {
  const checks = ['check-access', 'check-input', 'check-state', 'check-reentrant', 'check-events'];

  // Reset all to checking state
  checks.forEach(id => {
    const el = document.getElementById(id);
    const icon = el.querySelector('.check-icon');
    const status = el.querySelector('.check-status');
    icon.className = 'check-icon checking';
    icon.textContent = '◌';
    status.textContent = 'Checking...';
    status.className = 'check-status checking';
  });

  const results = await SecurityModule.runChecks(code, (result, idx) => {
    const el = document.getElementById(result.id);
    const icon = el.querySelector('.check-icon');
    const status = el.querySelector('.check-status');
    const desc = el.querySelector('.check-desc');

    if (result.passed) {
      icon.className = 'check-icon pass';
      icon.textContent = '✓';
      status.textContent = 'Pass';
      status.className = 'check-status pass';
    } else {
      icon.className = 'check-icon fail';
      icon.textContent = '✗';
      status.textContent = 'Warn';
      status.className = 'check-status fail';
    }
    desc.textContent = result.desc;
  });

  const score = SecurityModule.calculateScore(results);

  // Update score badge
  const badge = document.getElementById('securityScore');
  badge.textContent = score.grade;
  badge.className = `score-badge ${score.cls}`;

  // Show summary
  const summary = document.getElementById('securitySummary');
  summary.style.display = 'block';

  if (score.cls === 'pass') {
    summary.className = 'security-summary pass';
    summary.innerHTML = `✓ All ${score.total} security checks passed.<br/>Contract follows OP_NET best practices: access control, input validation, safe state transitions, reentrancy protection, and event logging are all verified.`;
  } else if (score.cls === 'warn') {
    summary.className = 'security-summary warn';
    summary.innerHTML = `⚠ ${score.passed}/${score.total} checks passed. Review flagged items before mainnet deployment. Testnet deployment is enabled.`;
  } else {
    summary.className = 'security-summary warn';
    summary.innerHTML = `⚠ ${score.passed}/${score.total} checks passed. Contract may have security gaps. Proceed with caution on testnet only.`;
  }

  // Enable deploy button
  const deployBtn = document.getElementById('deployBtn');
  deployBtn.disabled = false;

  return score;
}
