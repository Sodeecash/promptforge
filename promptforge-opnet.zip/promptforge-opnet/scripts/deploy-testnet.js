#!/usr/bin/env node
/**
 * PromptForge OP_NET — Testnet Deployment Script
 * 
 * Deploys compiled OP_NET smart contracts to Bitcoin Testnet
 * 
 * Usage:
 *   node scripts/deploy-testnet.js --contract EscrowContract --args '["tb1q...buyer","tb1q...seller","tb1q...arbiter"]'
 * 
 * Requirements:
 *   - npm install @btc-vision/sdk @btc-vision/btc-runtime
 *   - Compiled contract bytecode in ./dist/contracts/
 *   - OPNET_PRIVATE_KEY or OPNET_MNEMONIC environment variable set
 */

'use strict';

const path = require('path');
const fs   = require('fs');

// ——— Configuration ———
const OPNET_TESTNET_RPC  = process.env.OPNET_RPC_URL   || 'https://regtest.opnet.org';
const OPNET_EXPLORER     = process.env.OPNET_EXPLORER  || 'https://explorer.opnet.org/testnet';
const PRIVATE_KEY        = process.env.OPNET_PRIVATE_KEY;
const MNEMONIC           = process.env.OPNET_MNEMONIC;

// ——— Parse CLI args ———
const args = process.argv.slice(2);
const getArg = (flag) => {
  const idx = args.indexOf(flag);
  return idx !== -1 ? args[idx + 1] : null;
};

const contractName  = getArg('--contract') || 'EscrowContract';
const constructArgs = JSON.parse(getArg('--args') || '[]');
const dryRun        = args.includes('--dry-run');

async function main() {
  console.log('\n╔══════════════════════════════════════╗');
  console.log('║   PromptForge OP_NET Deployer v1.0   ║');
  console.log('║   Bitcoin Layer 1 · Testnet          ║');
  console.log('╚══════════════════════════════════════╝\n');

  console.log(`📋 Contract:  ${contractName}`);
  console.log(`🌐 Network:   OP_NET Testnet (Bitcoin Testnet4)`);
  console.log(`🔗 RPC:       ${OPNET_TESTNET_RPC}`);
  console.log(`📦 Args:      ${JSON.stringify(constructArgs)}`);
  console.log(`🧪 Dry run:   ${dryRun}\n`);

  if (!PRIVATE_KEY && !MNEMONIC) {
    console.error('❌ Error: Set OPNET_PRIVATE_KEY or OPNET_MNEMONIC env variable');
    console.error('   export OPNET_PRIVATE_KEY="your_wif_private_key_here"');
    process.exit(1);
  }

  // Check compiled artifact exists
  const artifactPath = path.join(__dirname, '..', 'dist', 'contracts', `${contractName}.js`);
  if (!fs.existsSync(artifactPath)) {
    console.error(`❌ Compiled artifact not found: ${artifactPath}`);
    console.error('   Run: npm run compile:contracts');
    process.exit(1);
  }

  if (dryRun) {
    console.log('🧪 DRY RUN — Simulating deployment...\n');
    await simulateDeploy(contractName, constructArgs);
    return;
  }

  try {
    // Dynamic import of @btc-vision/sdk
    let OPNetSDK;
    try {
      OPNetSDK = require('@btc-vision/sdk');
    } catch (e) {
      console.error('❌ @btc-vision/sdk not installed. Run: npm install @btc-vision/sdk');
      process.exit(1);
    }

    const { OPNetLimitedProvider, Wallet, ContractFactory, networks } = OPNetSDK;

    // Initialize provider
    console.log('🔌 Connecting to OP_NET Testnet...');
    const provider = new OPNetLimitedProvider(OPNET_TESTNET_RPC);
    const network  = networks.testnet;

    // Create wallet
    let wallet;
    if (PRIVATE_KEY) {
      wallet = Wallet.fromWIF(PRIVATE_KEY, provider, network);
    } else {
      wallet = Wallet.fromMnemonic(MNEMONIC, provider, network);
    }

    console.log(`💳 Deployer: ${wallet.address}`);

    // Check balance
    const balance = await provider.getBalance(wallet.address);
    console.log(`💰 Balance:  ${(balance / 1e8).toFixed(8)} BTC\n`);

    if (balance < 10000) {
      console.warn('⚠️  Low balance. Get testnet BTC from faucet:');
      console.warn('   https://bitcoinfaucet.uo1.net/');
      console.warn('   https://testnet.coinfaucet.eu/en/\n');
    }

    // Load bytecode
    const bytecode = fs.readFileSync(artifactPath);

    // Deploy via ContractFactory
    console.log(`🚀 Deploying ${contractName}...`);
    const factory    = new ContractFactory(wallet);
    const deployment = await factory.deploy(bytecode, constructArgs);

    console.log('\n✅ Deployment Successful!\n');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`📍 Contract Address: ${deployment.contractAddress}`);
    console.log(`🔗 Transaction Hash: ${deployment.transactionHash}`);
    console.log(`📦 Block Number:     ${deployment.blockNumber}`);
    console.log(`⛽ Gas Used (sats):  ${deployment.gasUsed}`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    console.log(`🔍 Explorer: ${OPNET_EXPLORER}/contract/${deployment.contractAddress}\n`);

    // Save deployment artifact
    const deployInfo = {
      contract: contractName,
      address: deployment.contractAddress,
      txHash: deployment.transactionHash,
      blockNumber: deployment.blockNumber,
      gasUsed: deployment.gasUsed,
      network: 'opnet-testnet',
      deployedAt: new Date().toISOString(),
      deployer: wallet.address,
      constructorArgs: constructArgs
    };

    const outDir = path.join(__dirname, '..', 'deployments');
    if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
    const outFile = path.join(outDir, `${contractName}-testnet-${Date.now()}.json`);
    fs.writeFileSync(outFile, JSON.stringify(deployInfo, null, 2));
    console.log(`💾 Saved deployment info: ${outFile}`);

  } catch (err) {
    console.error('\n❌ Deployment failed:', err.message);
    if (err.code === 'INSUFFICIENT_FUNDS') {
      console.error('💸 Insufficient testnet BTC. Use a faucet to get funds.');
    }
    process.exit(1);
  }
}

async function simulateDeploy(name, args) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const hex = n => [...Array(n)].map(() => Math.floor(Math.random() * 16).toString(16)).join('');

  const steps = [
    'Compiling contract bytecode...',
    'Encoding constructor arguments...',
    'Building Bitcoin transaction...',
    'Signing with deployer key...',
    'Broadcasting to OP_NET Testnet...',
    'Waiting for block confirmation...'
  ];

  for (const step of steps) {
    process.stdout.write(`  ⏳ ${step}`);
    await sleep(400);
    console.log(' ✓');
  }

  console.log('\n✅ [DRY RUN] Simulated deployment complete!\n');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`📍 Contract Address: tb1p${hex(38)}`);
  console.log(`🔗 Transaction Hash: ${hex(64)}`);
  console.log(`📦 Block Number:     ${(2800000 + Math.floor(Math.random() * 10000)).toLocaleString()}`);
  console.log(`⛽ Gas Used (sats):  ${(8000 + Math.floor(Math.random() * 4000)).toLocaleString()}`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  console.log('ℹ️  Remove --dry-run flag for live deployment\n');
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
