import { OP_NET, Address, u256, Blockchain, CallResponse, Event } from '@btc-vision/btc-runtime/runtime';

/**
 * @title MultiSigVault
 * @notice OP_NET M-of-N multi-signature Bitcoin vault
 * @network Bitcoin Testnet via OP_NET
 * @version 1.0.0
 */
export class MultiSigVault extends OP_NET {
  private readonly threshold: StoredU256  = new StoredU256(Blockchain.SELECTOR, 0);
  private readonly ownerCount: StoredU256 = new StoredU256(Blockchain.SELECTOR, 1);
  private readonly txNonce: StoredU256    = new StoredU256(Blockchain.SELECTOR, 2);
  private readonly locked: StoredBoolean  = new StoredBoolean(Blockchain.SELECTOR, 3);

  private approvals: Map<u256, u256>    = new Map();
  private executed: Map<u256, boolean>  = new Map();
  private approved: Map<string, boolean>= new Map();
  private owners: Set<Address>          = new Set();
  private txTargets: Map<u256, Address> = new Map();
  private txAmounts: Map<u256, u256>    = new Map();

  public readonly Proposed: Event  = Event.from('Proposed',  ['uint256', 'address', 'uint256', 'address']);
  public readonly Approved: Event  = Event.from('Approved',  ['uint256', 'address', 'uint256']);
  public readonly Executed: Event  = Event.from('Executed',  ['uint256', 'address', 'uint256']);
  public readonly Deposit: Event   = Event.from('Deposit',   ['address', 'uint256']);

  constructor(_owners: Address[], _threshold: u256) {
    super();
    this.require(_owners.length >= 2, 'Min 2 owners');
    this.require(_threshold >= u256(2), 'Threshold >= 2');
    this.require(_threshold <= u256(_owners.length), 'Threshold <= owner count');
    for (const o of _owners) {
      this.require(o !== Address.zero(), 'Zero address owner');
      this.owners.add(o);
    }
    this.threshold.set(_threshold);
    this.ownerCount.set(u256(_owners.length));
    this.txNonce.set(u256(0));
    this.locked.set(false);
  }

  @method
  public deposit(): CallResponse {
    const amount = Blockchain.msgValue();
    this.require(amount > u256(0), 'Deposit > 0');
    this.emit(this.Deposit, [Blockchain.msgSender(), amount]);
    return CallResponse.ok();
  }

  @method
  public propose(to: Address, amount: u256): CallResponse {
    this.requireOwner();
    this.require(amount > u256(0), 'Amount > 0');
    this.require(to !== Address.zero(), 'Invalid target');
    const nonce = this.txNonce.get();
    this.txTargets.set(nonce, to);
    this.txAmounts.set(nonce, amount);
    this.approvals.set(nonce, u256(0));
    this.executed.set(nonce, false);
    this.txNonce.set(nonce + u256(1));
    this.emit(this.Proposed, [nonce, to, amount, Blockchain.msgSender()]);
    return CallResponse.ok();
  }

  @method
  public approve(txId: u256): CallResponse {
    this.nonReentrant();
    this.requireOwner();
    this.require(!this.executed.get(txId), 'Already executed');
    const key = `${txId}:${Blockchain.msgSender()}`;
    this.require(!this.approved.get(key), 'Already approved');
    this.approved.set(key, true);
    const count = (this.approvals.get(txId) || u256(0)) + u256(1);
    this.approvals.set(txId, count);
    this.emit(this.Approved, [txId, Blockchain.msgSender(), count]);
    if (count >= this.threshold.get()) this.executeInternal(txId);
    this.unlock();
    return CallResponse.ok();
  }

  private executeInternal(txId: u256): void {
    this.executed.set(txId, true);
    const to = this.txTargets.get(txId)!;
    const amount = this.txAmounts.get(txId)!;
    Blockchain.transfer(to, amount);
    this.emit(this.Executed, [txId, to, amount]);
  }

  private requireOwner(): void { this.require(this.owners.has(Blockchain.msgSender()), 'Not owner'); }
  private nonReentrant(): void { this.require(!this.locked.get(), 'Reentrant'); this.locked.set(true); }
  private unlock(): void { this.locked.set(false); }

  @view public getInfo(): object {
    return { threshold: this.threshold.get(), owners: this.ownerCount.get(), txCount: this.txNonce.get() };
  }
}
